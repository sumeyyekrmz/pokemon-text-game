#include "type.h"
#include <stdio.h>
#include <string.h>

